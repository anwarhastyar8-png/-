-- V7 Stories: own-delete + admin-delete
-- Does not remove or change existing tables/data.

create or replace function public.delete_own_story(p_id bigint, p_name text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (
    select 1 from public.stories
    where id = p_id
      and lower(trim(author)) = lower(trim(p_name))
  ) then
    raise exception 'not_owner';
  end if;

  delete from public.stories
  where id = p_id
    and lower(trim(author)) = lower(trim(p_name));
end;
$$;

revoke all on function public.delete_own_story(bigint,text) from public;
grant execute on function public.delete_own_story(bigint,text) to anon, authenticated;

create or replace function public.admin_delete_story(p_id bigint, p_admin_name text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if p_admin_name not in (
    'حەمەی تاتۆ',
    'نینۆی خەیاڵ',
    'Muhamad Karim',
    'Kcha Barznji'
  ) then
    raise exception 'admin_only';
  end if;

  delete from public.stories
  where id = p_id;
end;
$$;

revoke all on function public.admin_delete_story(bigint,text) from public;
grant execute on function public.admin_delete_story(bigint,text) to anon, authenticated;
