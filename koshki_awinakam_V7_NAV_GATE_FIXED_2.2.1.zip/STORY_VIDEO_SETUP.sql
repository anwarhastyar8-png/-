-- V7 — زیادکردنی ڤیدیۆ بۆ ستۆری
-- وێنەکانی پێشوو هەر دەمێننەوە؛ هیچ داتایەک ناسڕدرێتەوە.

alter table public.stories
  alter column image_data drop not null;

alter table public.stories
  add column if not exists video_data text;

-- تەنها یەک جۆری میدیا بۆ هەر ستۆرییەک: وێنە یان ڤیدیۆ.
alter table public.stories
  drop constraint if exists stories_one_media_check;

alter table public.stories
  add constraint stories_one_media_check
  check (
    (image_data is not null and video_data is null)
    or
    (image_data is null and video_data is not null)
  );
