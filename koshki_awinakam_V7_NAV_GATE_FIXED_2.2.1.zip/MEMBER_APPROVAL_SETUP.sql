-- کۆشکی ئەوینەکەم V7
-- پەسەندکردنی ئەندامانی نوێ + ڕێگەدان بە ٤ ئەدمین بێ چاوەڕوانی

alter table public.members
add column if not exists approval_status text default 'approved';

update public.members
set approval_status = 'approved'
where approval_status is null;

alter table public.members
drop constraint if exists members_approval_status_check;

alter table public.members
add constraint members_approval_status_check
check (approval_status in ('pending','approved','rejected'));

create or replace function public.admin_set_member_status(
  p_id bigint,
  p_status text,
  p_admin_name text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if lower(trim(p_admin_name)) not in (
    lower(trim('حەمەی تاتۆ')),
    lower(trim('نینۆی خەیاڵ')),
    lower(trim('Muhamad Karim')),
    lower(trim('Kcha Barznji'))
  ) then
    raise exception 'admin_only';
  end if;

  if p_status not in ('approved','rejected') then
    raise exception 'invalid_status';
  end if;

  update public.members
  set approval_status = p_status
  where id = p_id;

  if not found then
    raise exception 'member_not_found';
  end if;
end;
$$;

revoke all on function public.admin_set_member_status(bigint,text,text)
from public;

grant execute on function public.admin_set_member_status(bigint,text,text)
to anon, authenticated;

alter table public.members enable row level security;

drop policy if exists members_select on public.members;
create policy members_select
on public.members
for select
using (true);

drop policy if exists members_insert on public.members;
create policy members_insert
on public.members
for insert
with check (true);

drop policy if exists members_update on public.members;
create policy members_update
on public.members
for update
using (true)
with check (true);
